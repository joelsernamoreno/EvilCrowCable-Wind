package com.example.evilcrowserver

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket

class MainActivity : AppCompatActivity() {
    private var commandInput: EditText? = null
    private var sendButton: Button? = null
    private var stopServerButton: Button? = null
    private var outputText: TextView? = null

    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null
    private var reader: BufferedReader? = null
    private var writer: OutputStream? = null

    private var serverThread: Thread? = null
    private var clientThread: Thread? = null
    private var uiHandler: Handler? = null
    private var isRunning: Boolean = false

    private val SERVER_PORT: Int = 4444

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        commandInput = findViewById(R.id.commandInput)
        sendButton = findViewById(R.id.sendButton)
        stopServerButton = findViewById(R.id.stopServerButton)
        outputText = findViewById(R.id.outputText)
        uiHandler = Handler(Looper.getMainLooper())
        sendButton?.setOnClickListener { sendCommand() }
        stopServerButton?.setOnClickListener { stopServer() }

        startServer()
    }

    private fun startServer() {
        isRunning = true

        serverThread = Thread {
            try {
                serverSocket = ServerSocket(SERVER_PORT)
                updateUI("Server started. Waiting for connection...")
                clientSocket = serverSocket?.accept()
                updateUI("Client connected: ${clientSocket?.inetAddress?.hostAddress}")
                reader = BufferedReader(InputStreamReader(clientSocket?.getInputStream()))
                writer = clientSocket?.getOutputStream()
                clientThread = Thread { receiveData() }
                clientThread?.start()
            } catch (e: Exception) {
                updateUI("Error starting server: ${e.message}")
            }
        }
        serverThread?.start()
    }

    private fun receiveData() {
        try {
            while (isRunning) {
                val line: String? = reader?.readLine()

                if (line != null) {
                    val finalLine = line.trim()

                    if (finalLine == "END_OF_COMMAND") {
                        uiHandler?.post { outputText?.append("\n") }
                    } else {
                        uiHandler?.post { outputText?.append("Wind: $finalLine\n") }
                    }
                }
            }
        } catch (e: Exception) {
            updateUI("Error receiving data: ${e.message}")
        }
    }

    private fun sendCommand() {
        if (clientSocket == null || clientSocket?.isClosed == true) {
            updateUI("No client connected.")
            return
        }

        val command = commandInput?.text.toString().trim()
        if (command.isEmpty()) return

        Thread {
            try {
                writer?.write("$command\n".toByteArray())
                writer?.flush()
                if (command.equals("exit", ignoreCase = true) || command.equals("quit", ignoreCase = true)) {
                    stopServer()
                }
            } catch (e: Exception) {
                updateUI("Error sending command: ${e.message}")
            }
        }.start()
    }

    private fun stopServer() {
        try {
            isRunning = false
            clientSocket?.close()
            serverSocket?.close()
            updateUI("Server stopped.")
        } catch (e: Exception) {
            updateUI("Error stopping server: ${e.message}")
        }
    }

    private fun updateUI(message: String) {
        uiHandler?.post { outputText?.append("$message\n") }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopServer()
    }
}
#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <thread>
#include <string>
#include <atomic>
#include <cstring> 

#pragma comment(lib, "ws2_32.lib")

#define BUFFER_SIZE 4096

std::atomic<bool> running(true);
SOCKET server_socket = INVALID_SOCKET;
SOCKET client_socket = INVALID_SOCKET;

void handle_client() {
    char buffer[BUFFER_SIZE];
    while (running) {
        int bytes_received = recv(client_socket, buffer, sizeof(buffer) - 1, 0);
        if (bytes_received <= 0) {
            std::cout << "\n[!] Client disconnected or error occurred.\n";
            running = false;
            break;
        }

        buffer[bytes_received] = '\0'; // Null-terminate the received string
        std::cout << buffer;
        std::cout.flush();
    }
}

void send_commands() {
    std::string command;
    while (running) {
        std::getline(std::cin, command);
        if (command == "exit" || command == "quit") {
            std::cout << "[*] Exiting...\n";
            running = false;
            break;
        }

        command += "\n";
        if (send(client_socket, command.c_str(), command.size(), 0) == SOCKET_ERROR) {
            std::cerr << "[!] Error sending command.\n";
            running = false;
            break;
        }
    }
}

int main(int argc, char* argv[]) {
    int port = 4444;

    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--port") == 0 && i + 1 < argc) {
            port = std::stoi(argv[i + 1]);
            i++;
        }
    }

    WSADATA wsa;
    struct sockaddr_in server_addr, client_addr;

    std::cout << "[*] Server started\n";
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        std::cerr << "[!] WSAStartup failed. Error Code: " << WSAGetLastError() << "\n";
        return 1;
    }

    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == INVALID_SOCKET) {
        std::cerr << "[!] Socket creation failed. Error Code: " << WSAGetLastError() << "\n";
        WSACleanup();
        return 1;
    }

    int opt = 1;
    setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, (const char*)&opt, sizeof(opt));

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(port);

    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == SOCKET_ERROR) {
        std::cerr << "[!] Bind failed. Error Code: " << WSAGetLastError() << "\n";
        closesocket(server_socket);
        WSACleanup();
        return 1;
    }

    if (listen(server_socket, 1) == SOCKET_ERROR) {
        std::cerr << "[!] Listen failed. Error Code: " << WSAGetLastError() << "\n";
        closesocket(server_socket);
        WSACleanup();
        return 1;
    }

    std::cout << "[*] Server listening on port " << port << "\n";

    int client_len = sizeof(client_addr);
    client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &client_len);
    if (client_socket == INVALID_SOCKET) {
        std::cerr << "[!] Accept failed. Error Code: " << WSAGetLastError() << "\n";
        closesocket(server_socket);
        WSACleanup();
        return 1;
    }

    char client_ip[INET_ADDRSTRLEN];
    InetNtopA(AF_INET, &client_addr.sin_addr, client_ip, INET_ADDRSTRLEN);

    std::cout << "[*] Connection established with "
        << client_ip << ":"
        << ntohs(client_addr.sin_port) << "\n";

    std::thread recv_thread(handle_client);
    std::thread send_thread(send_commands);

    recv_thread.join();
    send_thread.join();

    closesocket(client_socket);
    closesocket(server_socket);
    WSACleanup();
    std::cout << "[*] Server shut down.\n";

    return 0;
}

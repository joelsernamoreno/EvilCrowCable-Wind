#pragma once
#include <Arduino.h>
#include <functional>
#include "ECL_Usb.h"
#include "ecl_keys.h"

class EvilCrowKeyboard : public Print {
public:
  EvilCrowKeyboard();

  void begin();
  void end();
  size_t write(uint8_t k) override;
  size_t write(const uint8_t* buffer, size_t size) override;
  size_t press(uint8_t k);
  size_t release(uint8_t k);
  void   releaseAll();
  void   sendReport(EclKeyReport* keys);

  // Raw HID usage helpers (bypass ASCII map).
  size_t pressRaw(uint8_t usage);
  size_t releaseRaw(uint8_t usage);

  void setLayout(const uint8_t* layout) { _layout = layout; }
  void enableNkro() { _nkro = true; }   // call before begin()

  using LedFn = std::function<void(ecl_keyboard_leds_t)>;
  void onLedReport(LedFn fn) { _ledFn = fn; }
  void onEvent(LedFn fn) { onLedReport(fn); }

  static const uint8_t* reportDescriptor(uint16_t* len, bool nkro);

private:
  const uint8_t* _layout;
  bool _nkro = false;
  bool _began = false;
  EclKeyReport _report;         // 6KRO state
  uint8_t _nkroBitmap[16];      // NKRO state (usages 0x00..0x7F)
  LedFn _ledFn;

  void sendCurrent();
  friend void ecl_keyboard_led_bridge(uint8_t leds);
};

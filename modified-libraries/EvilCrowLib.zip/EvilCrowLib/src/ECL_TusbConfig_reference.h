/*
 * ECL_TusbConfig_reference.h  (REFERENCE ONLY - do not #include)
 * -----------------------------------------------------------------------------
 * EvilCrowLib uses the ARDUINO-ESP32 TinyUSB HAL, so you normally do NOT write a
 * tusb_config.h yourself - the Arduino core generates one from the interfaces we
 * enable. This file just records what the core must already provide:
 *
 *   HID / MSC : enabled on demand by tinyusb_enable_interface(); no action.
 *
 *   USB-Net   : Arduino-ESP32 3.3.x must provide one TinyUSB NET class slot
 *               (the stock USB-OTG build does). EvilCrowLib supplies isolated
 *               NCM and ECM/RNDIS backends and dispatches that slot to the
 *               mode selected before USB.begin(). No core rebuild is needed
 *               to switch among ECL_NET_NCM, ECL_NET_ECM and ECL_NET_RNDIS.
 *               Compatibility adapters cover the private API differences in
 *               TinyUSB 0.18 (core 3.3.0) and 0.21 (core 3.3.11).
 *
 * lwIP (for the Wi-Fi bridge / operator bridge): the core build must have
 *   IP forwarding + NAPT (CONFIG_LWIP_IP4_NAPT). Stock Arduino-ESP32 enables
 *   NAPT; if your variant does not, that is a core-rebuild item too.
 *
 * Board setting (Arduino IDE): Tools > USB Mode > "USB-OTG (TinyUSB)".
 * Do NOT call USB.begin() in the sketch; EvilCrowLib does it.
 * -----------------------------------------------------------------------------
 */

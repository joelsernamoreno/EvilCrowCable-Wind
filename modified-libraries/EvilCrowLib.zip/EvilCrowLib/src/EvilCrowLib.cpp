#include "EvilCrowLib.h"
EvilCrowKeyboard Keyboard;
EvilCrowMouse    Mouse;
EvilCrowConsumer Consumer;
EvilCrowSystem   SystemCtl;

#include "ECL_Msc.h"
#include "tusb.h"

static EclBlockDevice* s_dev = nullptr;
EclBlockDevice* EvilCrowMsc::active() { return s_dev; }
void EvilCrowMsc::begin(EclBlockDevice* dev) { s_dev = dev; Usb.enableMsc(); }

bool EvilCrowMscFatRam::format(uint32_t kib, const char* label) {
  _n = (kib * 1024) / 512;
  if (_img) free(_img);
  _img = (uint8_t*)calloc(_n, 512);
  if (!_img) { _n = 0; return false; }
  uint8_t* b = _img;
  // Boot sector (BPB) for FAT12.
  b[0]=0xEB; b[1]=0x3C; b[2]=0x90;
  memcpy(b+3, "MSDOS5.0", 8);
  b[11]=0x00; b[12]=0x02;            // 512 bytes/sector
  b[13]=0x01;                        // 1 sector/cluster
  b[14]=0x01; b[15]=0x00;            // reserved sectors
  b[16]=0x01;                        // 1 FAT
  b[17]=0x10; b[18]=0x00;            // 16 root entries
  b[19]=(uint8_t)(_n & 0xFF); b[20]=(uint8_t)(_n>>8);
  b[21]=0xF8;                        // media
  b[22]=0x01; b[23]=0x00;            // sectors/FAT
  b[24]=0x01; b[26]=0x01;
  b[38]=0x29;                        // ext boot sig
  memcpy(b+43, label, strlen(label)>11?11:strlen(label));
  memcpy(b+54, "FAT12   ", 8);
  b[510]=0x55; b[511]=0xAA;
  // FAT[0],[1] reserved.
  _img[512*1+0]=0xF8; _img[512*1+1]=0xFF; _img[512*1+2]=0xFF;
  return true;
}
int32_t EvilCrowMscFatRam::read(uint32_t lba,uint32_t off,void* d,uint32_t n){ if(lba>=_n) return -1; memcpy(d,_img+lba*512+off,n); return n; }
int32_t EvilCrowMscFatRam::write(uint32_t lba,uint32_t off,const void* d,uint32_t n){ if(lba>=_n) return -1; memcpy(_img+lba*512+off,d,n); return n; }

#if __has_include(<SD.h>)
#include <SD.h>
bool EvilCrowMscSd::begin(uint8_t csPin){ _cs=csPin; if(!SD.begin(csPin)) return false; _sectors = SD.numSectors(); return _sectors>0; }
int32_t EvilCrowMscSd::read(uint32_t lba,uint32_t off,void* b,uint32_t n){ (void)off; return SD.readRAW((uint8_t*)b,lba)?n:-1; }
int32_t EvilCrowMscSd::write(uint32_t lba,uint32_t off,const void* b,uint32_t n){ (void)off; return SD.writeRAW((uint8_t*)b,lba)?n:-1; }
#else
bool EvilCrowMscSd::begin(uint8_t){ return false; }
int32_t EvilCrowMscSd::read(uint32_t,uint32_t,void*,uint32_t){ return -1; }
int32_t EvilCrowMscSd::write(uint32_t,uint32_t,const void*,uint32_t){ return -1; }
#endif

extern "C" {
void tud_msc_inquiry_cb(uint8_t, uint8_t vid[8], uint8_t pid[16], uint8_t rev[4]) {
  const char* v = s_dev ? s_dev->vendor() : "EvilCrow";
  const char* p = s_dev ? s_dev->product() : "Storage";
  memset(vid,' ',8); memcpy(vid,v,strnlen(v,8));
  memset(pid,' ',16); memcpy(pid,p,strnlen(p,16));
  memcpy(rev,"1.0 ",4);
}
bool tud_msc_test_unit_ready_cb(uint8_t) { return s_dev != nullptr; }
void tud_msc_capacity_cb(uint8_t, uint32_t* block_count, uint16_t* block_size) {
  *block_count = s_dev ? s_dev->blockCount() : 0;
  *block_size  = s_dev ? s_dev->blockSize()  : 512;
}
bool tud_msc_is_writable_cb(uint8_t) { return s_dev && s_dev->writable(); }
int32_t tud_msc_read10_cb(uint8_t, uint32_t lba, uint32_t off, void* buf, uint32_t bufsize) {
  return s_dev ? s_dev->read(lba, off, buf, bufsize) : -1;
}
int32_t tud_msc_write10_cb(uint8_t, uint32_t lba, uint32_t off, uint8_t* buf, uint32_t bufsize) {
  return s_dev ? s_dev->write(lba, off, buf, bufsize) : -1;
}
int32_t tud_msc_scsi_cb(uint8_t, uint8_t const scsi_cmd[16], void* buffer, uint16_t bufsize) {
  (void)scsi_cmd; (void)buffer; (void)bufsize; return 0;
}
}

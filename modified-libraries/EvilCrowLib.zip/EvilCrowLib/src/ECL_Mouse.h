#pragma once
#include <Arduino.h>
#include "ECL_Usb.h"

#define MOUSE_LEFT   0x01
#define MOUSE_RIGHT  0x02
#define MOUSE_MIDDLE 0x04

class EvilCrowMouse {
public:
  void begin();
  void move(int8_t x, int8_t y, int8_t wheel = 0, int8_t pan = 0);
  void press(uint8_t b = MOUSE_LEFT);
  void release(uint8_t b = MOUSE_LEFT);
  void click(uint8_t b = MOUSE_LEFT);
  bool isPressed(uint8_t b = MOUSE_LEFT) const { return _buttons & b; }
  static const uint8_t* reportDescriptor(uint16_t* len);
private:
  uint8_t _buttons = 0;
  void send(int8_t x, int8_t y, int8_t w, int8_t p);
};

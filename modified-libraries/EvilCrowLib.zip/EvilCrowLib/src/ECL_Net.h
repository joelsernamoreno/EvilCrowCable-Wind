#pragma once
#include <Arduino.h>
#include "ECL_Usb.h"
#include "ECL_NetDriver.h"   // ecl_ncm_diag_t

struct netif;            // lwIP forward decl
struct esp_netif_obj;
typedef struct esp_netif_obj esp_netif_t;
typedef bool (*EclNetRawRxCallback)(const uint8_t* frame, uint16_t len,
                                    void* context);

class EvilCrowUsbNet {
public:
  bool begin(EclNetClass cls,
             IPAddress ip   = IPAddress(192,168,7,1),
             IPAddress mask = IPAddress(255,255,255,0),
             IPAddress gw   = IPAddress(192,168,7,1),
             IPAddress dns  = IPAddress(192,168,7,1));

  bool beginRawBridge(EclNetClass cls, const uint8_t mac[6],
                      EclNetRawRxCallback receive, void* context = nullptr);

  bool rawBridgeTransmit(const void* frame, uint16_t len,
                         uint32_t timeoutMs = 1000);

  void setRawBridgeLink(bool up);
  bool rawBridgeMode() const;
  void stop();
  static bool classSupported(EclNetClass cls);
  bool linkUp() const;
  IPAddress deviceIp() const { return _ip; }
  IPAddress hostIp()  const;
  EclNetClass mode()  const { return _cls; }

  struct netif* lwipNetif();
  esp_netif_t*  espNetif();
  bool enableNapt(bool on);
  const uint8_t* mac() const { return _mac; }
  const uint8_t* deviceMac() const;
  const uint8_t* hostMac() const;

  void setAdvertisedRouter(IPAddress gw, IPAddress dns);

  bool configureDhcp(bool offerRouter, IPAddress gw,
                     bool offerDns, IPAddress dns);

  bool naptEnabled() const;
  void setStatelessSnat(bool on, IPAddress deviceIp, IPAddress targetIp);
  bool statelessSnatEnabled() const;
  IPAddress snatOperator() const;

  void task();

  uint32_t txSent() const;
  uint32_t txDropped() const;
  uint32_t rxFrames() const;
  uint32_t txStalled() const;
  uint32_t rxStuck() const;

  void usbDiag(ecl_ncm_diag_t* out) const;

private:
  EclNetClass _cls = ECL_NET_OFF;
  IPAddress _ip, _mask, _gw, _dns;
  uint8_t   _mac[6] = {0x02,0x50,0xCA,0xDE,0x00,0x01};
  bool _up = false;
};

extern EvilCrowUsbNet UsbNet;

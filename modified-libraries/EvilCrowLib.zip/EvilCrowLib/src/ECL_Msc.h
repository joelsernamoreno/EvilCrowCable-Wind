#pragma once
#include <Arduino.h>
#include "ECL_Usb.h"

// Backend interface the TinyUSB MSC callbacks talk to.
class EclBlockDevice {
public:
  virtual uint32_t blockCount() = 0;
  virtual uint16_t blockSize()  { return 512; }
  virtual int32_t  read (uint32_t lba, uint32_t off, void* buf, uint32_t n) = 0;
  virtual int32_t  write(uint32_t lba, uint32_t off, const void* buf, uint32_t n) = 0;
  virtual bool     writable() { return true; }
  virtual const char* vendor()  { return "EvilCrow"; }
  virtual const char* product() { return "Storage"; }
};

class EvilCrowMsc {
public:
  void begin(EclBlockDevice* dev);
  static EclBlockDevice* active();
};

class EvilCrowMscRam : public EclBlockDevice {
public:
  EvilCrowMscRam(uint8_t* buf, uint32_t bytes) : _buf(buf), _n(bytes/512) {}
  uint32_t blockCount() override { return _n; }
  int32_t read(uint32_t lba,uint32_t off,void* b,uint32_t n) override { memcpy(b,_buf+lba*512+off,n); return n; }
  int32_t write(uint32_t lba,uint32_t off,const void* b,uint32_t n) override { memcpy(_buf+lba*512+off,b,n); return n; }
private: uint8_t* _buf; uint32_t _n;
};

class EvilCrowMscFatRam : public EclBlockDevice {
public:
  bool format(uint32_t kib = 64, const char* label = "EVILCROW");
  uint32_t blockCount() override { return _n; }
  int32_t read(uint32_t lba,uint32_t off,void* b,uint32_t n) override;
  int32_t write(uint32_t lba,uint32_t off,const void* b,uint32_t n) override;
  const char* product() override { return "FAT RamDisk"; }
private:
  uint8_t* _img = nullptr; uint32_t _n = 0;
};

class EvilCrowMscSd : public EclBlockDevice {
public:
  bool begin(uint8_t csPin);
  uint32_t blockCount() override { return _sectors; }
  int32_t read(uint32_t lba,uint32_t off,void* b,uint32_t n) override;
  int32_t write(uint32_t lba,uint32_t off,const void* b,uint32_t n) override;
  const char* product() override { return "SD Card"; }
private:
  uint32_t _sectors = 0; uint8_t _cs = 0;
};

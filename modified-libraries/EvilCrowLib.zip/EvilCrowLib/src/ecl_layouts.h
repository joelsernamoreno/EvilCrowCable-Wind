#pragma once

#include "layouts/en_us.h"
#include "layouts/es_es.h"
#include "layouts/fr_fr.h"
#include "layouts/it_it.h"
#include "layouts/de_de.h"
#include "layouts/da_dk.h"
#include "layouts/pt_pt.h"
#include "layouts/pt_br.h"
#include "layouts/be_be.h"
#include "layouts/br_br.h"
#include "layouts/ca_ca.h"
#include "layouts/ca_fr.h"
#include "layouts/hr_hr.h"
#include "layouts/hu_hu.h"
#include "layouts/cz_cz.h"
#include "layouts/sk_sk.h"
#include "layouts/sv_se.h"
#include "layouts/si_si.h"

struct EclLayoutEntry { const char* name; const uint8_t* table; };

static const EclLayoutEntry ECL_LAYOUTS[] = {
  { "EN_US", en_us }, { "ES_ES", es_es }, { "FR_FR", fr_fr }, { "IT_IT", it_it },
  { "DE_DE", de_de }, { "DA_DK", da_dk }, { "PT_PT", pt_pt }, { "PT_BR", pt_br },
  { "BE_BE", be_be }, { "BR_BR", br_br }, { "CA_CA", ca_ca }, { "CA_FR", ca_fr },
  { "HR_HR", hr_hr }, { "HU_HU", hu_hu }, { "CZ_CZ", cz_cz }, { "SK_SK", sk_sk },
  { "SV_SE", sv_se }, { "SI_SI", si_si },
};
static const size_t ECL_LAYOUTS_COUNT = sizeof(ECL_LAYOUTS)/sizeof(ECL_LAYOUTS[0]);

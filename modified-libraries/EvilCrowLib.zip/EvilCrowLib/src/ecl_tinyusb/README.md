# TinyUSB network sources

These files are vendored from TinyUSB commit
`2e0ea80091b2459089b9255a24122c9be4b9b4f2` (2025-07-22). Compatibility
wrappers adapt the backend to TinyUSB 0.18 in Arduino-ESP32 3.3.0 and TinyUSB
0.21 in Arduino-ESP32 3.3.11. The NCM backend additionally ports the TinyUSB
0.21 fixes for link-state restart, actual endpoint packet size, Ethernet packet
filter requests, and GET/SET_NTB_INPUT_SIZE negotiation.

EvilCrowLib compiles NCM and ECM/RNDIS in separate translation units with
namespaced public symbols, then dispatches Arduino-ESP32's single NET class slot
to the mode selected before USB enumeration. Original MIT license headers are
kept in every source/header copied from TinyUSB.

`usbd_018_ecl.inc` and `usbd_021_ecl.inc` are the exact TinyUSB device-core
sources bundled by Arduino-ESP32 3.3.0 (`8a78804ff`) and 3.3.11
(`53f8c53c2`). They contain the focused backport of upstream TinyUSB commit
`91fbbd192ca9539221d3dc096f00ce77836a5d3d`: when a full central queue drops a
transfer-completion event, BUSY and CLAIMED are cleared so the endpoint can be
re-armed. The backport first retains SETUP and transfer-completion events in a
16-entry recovery queue and replays them from the `usbd` task after the main
queue drains; this preserves NCM's NTB bookkeeping and the original transfer
length. The upstream clear is the fallback if even that recovery queue fills.
`ECL_UsbdQueuePatch.c` selects the matching source at compile time and increases
the main queue from 16 to 32 entries.

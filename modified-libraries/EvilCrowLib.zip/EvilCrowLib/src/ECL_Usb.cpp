#include "ECL_Usb.h"
#include "ECL_NetDriver.h"

#if defined(SOC_USB_OTG_SUPPORTED) && SOC_USB_OTG_SUPPORTED && __has_include("esp32-hal-tinyusb.h")
  #include "USB.h"
  #include "esp32-hal-tinyusb.h"
  #include "tusb.h"
  #define ECL_USB_HAL 1
#else
  #define ECL_USB_HAL 0
#endif

#ifndef CFG_TUD_HID_EP_BUFSIZE
#define CFG_TUD_HID_EP_BUFSIZE 64
#endif
#ifndef CFG_TUD_NET_MTU
#define CFG_TUD_NET_MTU 1514
#endif

EvilCrowUSB Usb;
EvilCrowUSB::EvilCrowUSB() {}
EvilCrowUSB& EvilCrowUSB::instance() { return Usb; }

static EvilCrowUSB* s_active = nullptr;
static bool        s_has_hid = false, s_has_msc = false, s_has_net = false;
static EclNetClass s_net_cls = ECL_NET_OFF;

static bool eclUsbNetClassCompiled(EclNetClass cls) {
#if ECL_USB_HAL
  return ecl_net_driver_supports((uint8_t)cls);
#else
  (void)cls;
  return false;
#endif
}

void EvilCrowUSB::enableHid(const EclHidFragment& frag) { _useHid = true; _frags.push_back(frag); }
void EvilCrowUSB::enableMsc() { _useMsc = true; }
void EvilCrowUSB::enableNet(EclNetClass cls) {
  if (cls != ECL_NET_OFF && eclUsbNetClassCompiled(cls)) {
    ecl_net_driver_select((uint8_t)cls);
    _netClass = cls;
  }
}
void EvilCrowUSB::setNetClass(EclNetClass cls) {
  if (cls != ECL_NET_OFF && eclUsbNetClassCompiled(cls)) {
    ecl_net_driver_select((uint8_t)cls);
    _netClass = cls;
  } else {
    _netClass = ECL_NET_OFF;
  }
}

void EvilCrowUSB::buildHidReport(const std::vector<EclHidFragment>& frags) {
  _hidReport.clear();
  for (auto& f : frags)
    _hidReport.insert(_hidReport.end(), f.report_desc, f.report_desc + f.report_len);
}

const uint8_t* EvilCrowUSB::hidReportDescriptor(uint16_t* out_len) const {
  if (out_len) *out_len = _hidReport.size();
  return _hidReport.data();
}

#if ECL_USB_HAL

extern "C" {

static uint16_t eclLoadHid(uint8_t* dst, uint8_t* itf) {
  if (!s_active) return 0;
  uint16_t rlen = 0; s_active->hidReportDescriptor(&rlen);
  const uint8_t strIndex = tinyusb_add_string_descriptor("ECL HID");
  uint8_t d[] = { TUD_HID_INOUT_DESCRIPTOR(*itf, strIndex, HID_ITF_PROTOCOL_NONE,
                    rlen, 0x01, 0x81, CFG_TUD_HID_EP_BUFSIZE, 1) };
  memcpy(dst, d, sizeof(d));
  *itf = (uint8_t)(*itf + 1);
  return sizeof(d);
}

static uint16_t eclLoadMsc(uint8_t* dst, uint8_t* itf) {
  const uint8_t strIndex = tinyusb_add_string_descriptor("ECL Mass Storage");
  const uint8_t epNum = tinyusb_get_free_duplex_endpoint();
  if (epNum == 0) return 0;
  uint8_t d[] = { TUD_MSC_DESCRIPTOR(*itf, strIndex, epNum, (uint8_t)(0x80 | epNum), 64) };
  memcpy(dst, d, sizeof(d));
  *itf = (uint8_t)(*itf + 1);
  return sizeof(d);
}

static uint16_t eclLoadNet(uint8_t* dst, uint8_t* itf) {
  extern uint8_t tud_network_mac_address[6];       // defined in ECL_Net.cpp
  static char macstr[13];
  static const char* hex = "0123456789ABCDEF";
  for (int i = 0; i < 6; i++) {
    macstr[i * 2]     = hex[(tud_network_mac_address[i] >> 4) & 0x0f];
    macstr[i * 2 + 1] = hex[tud_network_mac_address[i] & 0x0f];
  }
  macstr[12] = '\0';
  const uint8_t strIndex    = tinyusb_add_string_descriptor("ECL Network");
  const uint8_t macStrIndex = tinyusb_add_string_descriptor(macstr);
  const uint8_t epNotif = tinyusb_get_free_in_endpoint();
  const uint8_t epIn    = tinyusb_get_free_in_endpoint();
  const uint8_t epOut   = tinyusb_get_free_out_endpoint();
  if (epNotif == 0 || epIn == 0 || epOut == 0) return 0;

  if (s_net_cls == ECL_NET_NCM) {
#if TUSB_VERSION_NUMBER >= 2100
    uint8_t d[] = { TUD_CDC_NCM_DESCRIPTOR(*itf, strIndex, macStrIndex,
                      (uint8_t)(0x80 | epNotif), 64, epOut, (uint8_t)(0x80 | epIn), 64,
                      CFG_TUD_NET_MTU, 16, 0x21) };
#else
    uint8_t d[] = { TUD_CDC_NCM_DESCRIPTOR(*itf, strIndex, macStrIndex,
                      (uint8_t)(0x80 | epNotif), 64, epOut, (uint8_t)(0x80 | epIn), 64,
                      CFG_TUD_NET_MTU) };

    d[8 + 9 + 5 + 5 + 13 + 5] = 0x21;
#endif
    static_assert(sizeof(d) == TUD_CDC_NCM_DESC_LEN, "NCM descriptor length mismatch");
    memcpy(dst, d, sizeof(d)); *itf = (uint8_t)(*itf + 2); return sizeof(d);
  }
#if defined(TUD_CDC_ECM_DESCRIPTOR)
  else if (s_net_cls == ECL_NET_ECM) {
    uint8_t d[] = { TUD_CDC_ECM_DESCRIPTOR(*itf, strIndex, macStrIndex,
                      (uint8_t)(0x80 | epNotif), 64, epOut, (uint8_t)(0x80 | epIn), 64,
                      CFG_TUD_NET_MTU) };
    static_assert(sizeof(d) == TUD_CDC_ECM_DESC_LEN, "ECM descriptor length mismatch");
    memcpy(dst, d, sizeof(d)); *itf = (uint8_t)(*itf + 2); return sizeof(d);
  }
#endif
#if defined(TUD_RNDIS_DESCRIPTOR)
  else if (s_net_cls == ECL_NET_RNDIS) {
    uint8_t d[] = { TUD_RNDIS_DESCRIPTOR(*itf, strIndex,
                      (uint8_t)(0x80 | epNotif), 8, epOut, (uint8_t)(0x80 | epIn), 64) };
    static_assert(sizeof(d) == TUD_RNDIS_DESC_LEN, "RNDIS descriptor length mismatch");
    memcpy(dst, d, sizeof(d)); *itf = (uint8_t)(*itf + 2); return sizeof(d);
  }
#endif
  return 0;
}

} // extern "C"
#endif // ECL_USB_HAL

bool EvilCrowUSB::begin() {
#if ECL_USB_HAL
  if (_netClass != ECL_NET_OFF && !eclUsbNetClassCompiled(_netClass)) return false;
  buildHidReport(_frags);
  s_active  = this;
  s_has_hid = _useHid;
  s_has_msc = _useMsc;
  s_has_net = (_netClass != ECL_NET_OFF);
  s_net_cls = _netClass;

  USB.VID(_cfg.vid);
  USB.PID(_cfg.pid);
  USB.firmwareVersion(_cfg.bcdDevice);
  USB.productName(_cfg.product);
  USB.manufacturerName(_cfg.manufacturer);
  USB.serialNumber(_cfg.serial);
  USB.usbClass(TUSB_CLASS_MISC);
  USB.usbSubClass(MISC_SUBCLASS_COMMON);
  USB.usbProtocol(MISC_PROTOCOL_IAD);

  esp_err_t err;
  if (s_has_hid) {
    err = tinyusb_enable_interface2(USB_INTERFACE_HID, TUD_HID_INOUT_DESC_LEN, eclLoadHid, true);
    if (err != ESP_OK) return false;
  }
  if (s_has_msc) {
    err = tinyusb_enable_interface(USB_INTERFACE_MSC, TUD_MSC_DESC_LEN, eclLoadMsc);
    if (err != ESP_OK) return false;
  }
  if (s_has_net) {
    uint16_t netLen = TUD_CDC_NCM_DESC_LEN;
#if defined(TUD_CDC_ECM_DESC_LEN)
    if (s_net_cls == ECL_NET_ECM) netLen = TUD_CDC_ECM_DESC_LEN;
#endif
#if defined(TUD_RNDIS_DESC_LEN)
    if (s_net_cls == ECL_NET_RNDIS) netLen = TUD_RNDIS_DESC_LEN;
#endif
    err = tinyusb_enable_interface(USB_INTERFACE_CUSTOM, netLen, eclLoadNet);
    if (err != ESP_OK) return false;
  }

  if (!USB.begin()) return false;
  _installed = true;
  return true;
#else
  return false;
#endif
}

bool EvilCrowUSB::mounted() const {
#if ECL_USB_HAL
  return tud_mounted();
#else
  return false;
#endif
}
void EvilCrowUSB::task() { /* core runs the tinyusb task */ }

bool EvilCrowUSB::hidReady() const {
#if ECL_USB_HAL
  return tud_hid_ready();
#else
  return false;
#endif
}

#ifndef ECL_HID_REPORT_TIMEOUT_MS
#define ECL_HID_REPORT_TIMEOUT_MS 50U
#endif

bool EvilCrowUSB::hidSendReport(uint8_t rid, const void* data, uint8_t len) {
#if ECL_USB_HAL
  if (!tud_mounted()) return false;

  const uint32_t start = millis();
  while (!tud_hid_ready()) {
    if (!tud_mounted()) return false;
    if (millis() - start >= ECL_HID_REPORT_TIMEOUT_MS) return false;
    delay(1);
  }
  return tud_hid_report(rid, data, len);
#else
  (void)rid; (void)data; (void)len;
  return false;
#endif
}

#if ECL_USB_HAL
extern "C" {

uint8_t const* tud_hid_descriptor_report_cb(uint8_t) {
  uint16_t l = 0; return s_active ? s_active->hidReportDescriptor(&l) : nullptr;
}

uint16_t tud_hid_get_report_cb(uint8_t, uint8_t, hid_report_type_t, uint8_t*, uint16_t) {
  return 0;
}

void tud_hid_set_report_cb(uint8_t /*instance*/, uint8_t report_id,
                           hid_report_type_t type, uint8_t const* buffer, uint16_t bufsize) {
  if (!s_active) return;
  if (type != HID_REPORT_TYPE_OUTPUT) return;
  if (report_id == 0 && bufsize >= 1) {
    // Report ID is embedded as the first byte.
    uint8_t rid = buffer[0];
    if (rid == ECL_RID_KEYBOARD && bufsize >= 2)      s_active->_dispatchLeds(buffer[1]);
    else if (rid == ECL_RID_RAW || rid == ECL_RID_CUSTOM) s_active->_dispatchRaw(buffer + 1, bufsize - 1);
  } else if (report_id == ECL_RID_KEYBOARD && bufsize >= 1) {
    s_active->_dispatchLeds(buffer[0]);
  } else if (report_id == ECL_RID_RAW || report_id == ECL_RID_CUSTOM) {
    s_active->_dispatchRaw(buffer, bufsize);
  }
}

} // extern "C"
#endif // ECL_USB_HAL
